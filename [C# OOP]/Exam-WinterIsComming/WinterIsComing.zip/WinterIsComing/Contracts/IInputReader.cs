﻿namespace WinterIsComing.Contracts
{
    public interface IInputReader
    {
        string ReadNextLine();
    }
}