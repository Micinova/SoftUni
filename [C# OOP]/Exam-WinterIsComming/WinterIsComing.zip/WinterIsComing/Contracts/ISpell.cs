﻿namespace WinterIsComing.Contracts
{
    public interface ISpell
    {
        int Damage { get; }

        int EnergyCost { get; }
    }
}